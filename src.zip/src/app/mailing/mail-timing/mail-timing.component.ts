import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mail-timing',
  templateUrl: './mail-timing.component.html',
  styleUrls: ['./mail-timing.component.css']
})
export class MailTimingComponent implements OnInit {
  
  selectColor = 'warning';
    
    cities = [
      {value: 'paris-0', viewValue: 'Paris'},
      {value: 'miami-1', viewValue: 'Miami'},
      {value: 'bucharest-2', viewValue: 'Bucharest'},
      {value: 'new-york-3', viewValue: 'New York'},
      {value: 'london-4', viewValue: 'London'},
      {value: 'barcelona-5', viewValue: 'Barcelona'},
      {value: 'moscow-6', viewValue: 'Moscow'},
    ];
    
 mailType = [
      {value: 'Type-1', viewValue: 'Type-1'},
      {value: 'Type-2', viewValue: 'Type-2'},
      {value: 'Type-3', viewValue: 'Type-3'},
      {value: 'Type-4', viewValue: 'Type-4'},
    ];

  constructor(private router:Router) { }
   
  navigateTo(){
    this.router.navigateByUrl("/mail/selectdesign");
  }
  ngOnInit() {
  }

}

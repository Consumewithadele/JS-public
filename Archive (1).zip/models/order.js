// order model
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const config = require("../config/database");

const OrderSchema = mongoose.Schema({
    date: {
        type: Date,
        default: Date.now
    },
    invoice: {
        type: Object
    },
    amount: {
        type: Number
    },
    buyer: {
        type: String,
        required: true
    },
    seller: {
        type: String
    },
    current_status: {
        type: String,
        required: true
    },
    tracking: {
        type: Object
    },
    ip: {
        type: String
    },
    link: {
        type: String
    }
})

const Orders = mongoose.model('Order', OrderSchema);

// Get a single order by id
module.exports.getOrderById = (id, callback) => {
    const query = { _id: id };
    Orders.findOne(query, callback);
}

// Get orders from a specific seller
module.exports.getOrdersOfSeller = (seller, page, callback) => {
    const query = {seller: seller};
    Orders.find(query, callback)
    .limit(20)
    .skip(20 * page);
}

// Get all Orders of a specific buyer by id
module.exports.getOrdersByBuyerId = (buyer, page, callback) => {
    const query = {buyer: buyer};
    Orders.find(query, callback)
    .limit(20)
    .skip(20 * page);
}

// Get All Orders 
module.exports.getOrders = (page, callback) => {
    Orders.find(callback)
    .limit(20)
    .skip(20 * page);
}

// Add order
module.exports.addOrder = (newOrder, callback) => {
    const order = new Orders(newOrder);
    order.save(callback)
}

//Edit Order
module.exports.editOrder = (orderItem, callback) => {
    const query = { _id: orderItem._id };
    Orders.update(query, orderItem, callback);

};

// Delete order
module.exports.deleteOrder = (id, callback) => {
    Orders.remove({_id: id}, callback)
};
// tracking history model
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const config = require("../config/database");

const trackingHistorySchema = mongoose.Schema({
    by_whom: {
        type: String,
        required: true
    }, 
    to_whom:{
        type: String,
        required: true
    }, 
    location: {
        type: String
    }, 
    distance_travel: {
        type: String
    }, 
    date:{
        type: Date,
        default: Date.now
    }, 
    time: {
        type: Date,
        default: Date.now
    }
});

const TRACKING_HISTORY = mongoose.model('Tracking_History', trackingHistorySchema);

//  add employee
module.exports.addtrackingHistory = (newTracking, callback) => {
    const tracking = new TRACKING_HISTORY(newTracking);
    tracking.save(callback);
}   

// edit tracking history
module.exports.editTrackingHistory = (tracking, callback) => {
    const query = {_id: tracking._id};
    TRACKING_HISTORY.update(query, tracking, callback);
}

// delete tracking hostory
module.exports.deleteTrackingHistory = (id, callback) => {
    const query = {_id: id};
    TRACKING_HISTORY.remove(query, callback)
}

// Get tracking hostories 
module.exports.getTrackingHistories = (page, callback) => {
    TRACKING_HISTORY.find(callback)    
    .limit(20)
    .skip(20 * page);  ;
}

// Get tracking-history by Id 
module.exports.getTrackingHistoryById = (id, callback) => {
    const query = {_id: id};
    TRACKING_HISTORY.findOne(query, callback);
}
/*This is the main app entry point*/
// Depencies
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();

// app port
const port = 3000;

// Bodyparser middleware
app.use(bodyParser.json());

// App index route
app.get('/', (req, res) => {
    res.send("Invalid entry point.");
});

// Create charge
app.post('/api/charge', (req, res) => {
    let token = req.body.token;
    let amount = req.body.amount;
    let receipt_email = req.body.receipt_email;
    let description = req.body.description;
    let currency = req.body.currency;
    let charge = stripe.charges.create({
        amount: amount,
        currency: currency,
        source: token,
        receipt_email: receipt_email,
        description: description,
    }, (err, charge) => {
        if (err) {
            res.json({ success: false, data: err })
        } else {
            res.json({ success: true, data: charge })
        }
    })
});

// Create using customer id
app.post('/api/charge-customer', (req, res) => {
    let customer = req.body.customerId;
    let amount = req.body.amount;
    let description = req.body.description;
    let currency = req.body.currency;
    let charge = stripe.charges.create({
        amount: amount,
        currency: currency,
        customer: customer,
        description: description,
    }, (err, charge) => {
        if (err) {
            res.json({ success: false, data: err })
        } else {
            res.json({ success: true, data: charge })
        }
    })
})

// Create customer
app.post('/api/create-customer', (req, res) => {
    let token = req.body.token;
    let email = req.body.email;
    let description = req.body.description;
    let customer = stripe.customers.create({
        source: token,
        description: description,
        email: email
    }, (err, customer) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: customer })
        }
    })
});

// Retrieve a customer by customer_id
app.get('/api/retrieve-customer/:customerId', (req, res) => {
    let customerId = req.params.customerId;
    let customer = stripe.customers.retrieve(customerId, (err, customer) => {
        if (err) {
            res.json({ success: false, data: err })
        } else {
            res.json({ success: true, data: customer })
        }
    })
});

// Update a customer
app.put('/api/update-customer/:customerId', (req, res) => {
    let customerId = req.params.customerId;
    let data = req.body;
    let callback = stripe.customers.update(customerId, data, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: callback });
        }
    })
});

// Delete customer
app.post('/api/delete-customer', (req, res) => {
    let customerId = req.body.customerId;
    let callback = stripe.customers.del(customerId, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: callback });
        }
    })
});

// Retrieve a charge by id
app.get('/api/retrieve-charge/:id', (req, res) => {
    let chargeId = req.params.id;
    let charge = stripe.charges.retrieve(chargeId, (err, charge) => {
        if (err) {
            res.json({ success: false, data: err })
        } else {
            res.json({ success: true, data: charge })
        }
    })
});

// Show charge history
app.post('/api/list-charges', (req, res) => {
    let customerId = req.body.customerId;
    let limit = req.body.limit;
    let chargelist = stripe.charges.list(
        { customer: customerId, limit: limit }, (err, charges) => {
            if (err) {
                res.json({ success: false, data: err })
            } else {
                res.json({ success: true, data: charges })
            }
        })
});

// Add card to under a specific user
app.post('/api/add-card', (req, res) => {
    let customerId = req.body.customerId;
    let source = req.body.token;
    let addCard = stripe.customers.createSource(
        customerId,
        { source: source }, (err, card) => {
            if (err) {
                res.json({ success: false, data: err })
            } else {
                res.json({ success: true, data: card })
            }
        }
    );
});

// Update a card
app.put('/api/update-card', (req, res) => {
    let cardId = req.body.cardId;
    let customerId = req.body.customerId;
    let data = req.body;
    let card = stripe.customers.updateCard(customerId, cardId, data, (err, card) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: card });
        }
    })
});

// Delete card
app.post('/api/delete-card', (req, res) => {
    let cardId = req.body.cardId;
    let customerId = req.body.customerId;
    let callback = stripe.customers.deleteCard(customerId, cardId, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: callback });
        }
    })
});

// Create app server
app.listen(3000, () => {
    console.log("App running  on port:" + port);
})

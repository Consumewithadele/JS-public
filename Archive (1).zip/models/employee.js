// employee model
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const config = require("../config/database");

const employeeSchema = mongoose.Schema({
     retailer: {
         type: String,
         required: true
     }, 
     emp_id: {
         type: String,
     }, 
     emp_name: {
         type: String,
         required: true
     }, 
     country_code:{
         type: String,
         required: true
     },
     mobile: {
         type: Number,
         required: true
     }, 
     status: {
         type: Boolean,
         required: true
     }, 
     role: {
         type: String,
         required: true
     }
});

const EMPLOYEE = mongoose.model('Employee', employeeSchema);

//  add employee
module.exports.addEmployee = (newEmployee, callback) => {
    const employee = new EMPLOYEE(newEmployee);
    employee.save(callback);
}   

// edit employee
module.exports.editEmployee = (employeeItem, callback) => {
    const query = {_id: employeeItem.id};
    EMPLOYEE.update(query, employeeItem, callback);
}

// delete employee
module.exports.deleteEmployee = (id, callback) => {
    const query = {_id: id};
    EMPLOYEE.remove(query, callback)
}

// Get employees 
module.exports.getEmployees = (page, callback) => {
    EMPLOYEE.find(callback)
    .limit(20)
    .skip(20 * page)
    .sort({
        emp_name: 'asc'
    }); 
}

// Get employee by Id 
module.exports.getEmployeeById = (id, callback) => {
    const query = {_id: id};
    EMPLOYEE.findOne(query, callback);
}
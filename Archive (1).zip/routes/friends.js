// Friends route
const express = require('express');
const router = express.Router();
const passport = require('passport');
const Friends = require('../models/friends');
const jwt = require('jsonwebtoken');
const config = require('../config/database');

/**
 * @api {get} /:id Get Friend with id
 * @apiName GetFriend
 * @apiGroup Friend
 * 
 * @apiParam {Number} id Friend ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": friend
 *     }
 *
 * @apiSuccess {Friend} get a friend
 */
router.get('/:id', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let id = req.params.id;
    Friends.getFriendById(id, (err, friend)=> {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: friend });
        }
    })
});

/**
 * @api {post} /add-friend/ Add a Friend
 * @apiName AddFriend
 * @apiGroup Friend
 *
 * @apiParam {Number} user_id Users ID
 * @apiParam {String} status Friend status
 * @apiParam {String} tracking Friend tracking
 *
 * @apiSuccess FriendAdded
 * 
 *  @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "message": "Friend Added!"
 *     }
 * 
 * @apiError ErrorMessage
 * 
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Error message"
 *     }
 */
router.post('/add-friend', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let transaction = req.body;
    Friends.addFriend(transaction, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: "Friend Added!" });
        }
    })
});

// Get all friends for a particular user (params: page, user_id)
/**
 * @api {get} /:user_id/list-friends Get all friends for a particular user
 * @apiName GetFriends
 * @apiGroup Friend
 * 
 * @apiParam {Number} page Page number
 * @apiParam {Number} user_id User ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": friends
 *     }
 *
 * @apiSuccess {Employee} List of employees with a specific retailerId
 */
router.get('/:user_id/list-friends', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let page = req.params.page;
    let user_id = req.params.user_id;
    Friends.getUserFriends(user_id, page, (err, friends) => {
        if (err) {
            res.json({success: false, data: err})
        } else {
            res.json({success: true, data: friends })
        }
    })
});

/**
 * @api {put} /friend Update an Friend
 * @apiName UpdateFriend
 * @apiGroup Employee
 *
 * @apiParam {Number} user_id Users ID
 * @apiParam {String} status Friend status
 * @apiParam {String} tracking Friend tracking
 *
 * @apiSuccess FriendUpdated
 * 
 *  @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": "updated!"
 *     }
 * 
 * @apiError ErrorMessage
 * 
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Error message"
 *     }
 */
router.put('/friend', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let friend =  req.body;
    Friends.editFriend(transaction, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err })
        } else {
            res.json({ success: true, data: "updated!" })
        }
    })
});

/**
 * @api {delete} /friend/:id Delete Friend with id
 * @apiName DeleteFriend
 * @apiGroup Friend
 * 
 * @apiParam {Number} id Friend ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": "deleted!"
 *     }
 *
 */
router.delete('/friend/:id', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let id = req.params.id;
    Friends.deleteFriend(id, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err })
        } else {
            res.json({ success: true, data: " deleted!" })
        }
    })
})
module.exports = router;
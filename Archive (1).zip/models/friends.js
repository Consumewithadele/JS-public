// friends model
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const config = require("../config/database");

const friendsSchema = mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId, "ref": 'user'
    },
    status: {
        type: String,
        required: true
    },
    tracking: {
        type: String,
        required: true
    }
});

const FRIENDS = mongoose.model('Friends', friendsSchema);

// Get a friend by id
module.exports.getFriendById = (id, callback) => {
    const query = { _id: id };
    FRIENDS.findOne(query, callback);
}

// Get friends of a particular user
module.exports.getUserFriends = (user_id, page, callback) => {
    const query = { user_id: user_id };
    FRIENDS.find(query, callback)
        .limit(20)
        .skip(20 * page)
}

// Add friend
module.exports.addFriend = (newFriend, callback) => {
    const friend = new FRIENDS(newFriend);
    friend.save(callback)
}

//Edit friend
module.exports.editFriend = (friend, callback) => {
    const query = { _id: friend._id };
    FRIENDS.update(query, address, callback);

}

// Delete friend
module.exports.deleteAddress = (id, callback) => {
    const query = { _id: id };
    FRIENDS.remove(query, callback);
}
// Wallet rtransactions routes
const express = require('express');
const router = express.Router();
const passport = require('passport');
const WalletTransactions = require('../models/wallet_transaction');
const jwt = require('jsonwebtoken');
const config = require('../config/database');

/**
 * @api {get} /transaction/:id Get Wallet transaction with specific id
 * @apiName GetTransaction
 * @apiGroup WalletTransaction
 * 
 * @apiParam {Number} id Wallet Transaction ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": transaction
 *     }
 *
 * @apiSuccess {WalletTransaction} Wallet transaction
 */
router.get('/transaction/:id', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let id = req.params.id;
    WalletTransactions.getTransactionById(id, (err, transaction)=> {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: transaction });
        }
    })
});

/**
 * @api {post} /add-transaction/ Add a Wallet Transaction
 * @apiName AddWalletTransaction
 * @apiGroup WalletTransaction
 *
 * @apiParam {Date} date Wallet transaction date
 * @apiParam {User} sender Sender
 * @apiParam {User} receiver Receiver
 * @apiParam {String} currency Transaction currency
 * @apiParam {Number} amount transaction amount
 * @apiParam {String} note transaction note
 * @apiParam {Number} exchange_rate Exchange rate for Transaction
 * @apiParam {String} ip Transaction ip
 *
 * @apiSuccess WalletTransactionAdded
 * 
 *  @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "message": "transaction recorded!"
 *     }
 * 
 * @apiError ErrorMessage
 * 
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Error message"
 *     }
 */
router.post('/add-transaction', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let transaction = req.body;
    WalletTransactions.createTransaction(transaction, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: "transaction recorded!" });
        }
    })
});

/**
 * @api {get} /list-transactions/ Get Transactions
 * @apiName GetWalletTransaction
 * @apiGroup WalletTransaction
 * 
 * @apiParam {Number} page Page number for Wallet Transaction
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": transactions
 *     }
 *
 * @apiSuccess {WalletTransaction} All Wallet Transaction on said page
 */
router.get('/list-transactions', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let page = req.params.page;
    WalletTransactions.getTransactions(page, (err, transactions) => {
        if (err) {
            res.json({success: false, data: err})
        } else {
            res.json({success: true, data: transactions})
        }
    })
});

/**
 * @api {put} /transaction/ Update a Wallet Transaction
 * @apiName AddWalletTransaction
 * @apiGroup WalletTransaction
 *
 * @apiParam {Date} date Wallet transaction date
 * @apiParam {User} sender Sender
 * @apiParam {User} receiver Receiver
 * @apiParam {String} currency Transaction currency
 * @apiParam {Number} amount transaction amount
 * @apiParam {String} note transaction note
 * @apiParam {Number} exchange_rate Exchange rate for Transaction
 * @apiParam {String} ip Transaction ip
 *
 * @apiSuccess WalletTransactionUpdated
 * 
 *  @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "message": "Item updated!"
 *     }
 * 
 * @apiError ErrorMessage
 * 
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Error message"
 *     }
 */
router.put('/transaction', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let transaction =  req.body;
    WalletTransactions.editTransaction(transaction, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err })
        } else {
            res.json({ success: true, data: "Item updated!" })
        }
    })
});

/**
 * @api {delete} /transaction/:id Delete transaction with ID
 * @apiName DeleteWalletTransaction
 * @apiGroup WalletTransaction
 * 
 * @apiParam {Number} id Wallet Transaction ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": "Item Removed!"
 *     }
 *
 */
router.delete('/transaction/:id', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let id = req.params.id;
    WalletTransactions.deleteTransaction(id, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err })
        } else {
            res.json({ success: true, data: "Item deleted!" })
        }
    })
})
module.exports = router;

// This is retailer routes
const express = require('express');
const router = express.Router();
const passport = require('passport');
const Retailer = require('../models/retailer');
const jwt = require('jsonwebtoken');
const config = require('../config/database');

router.post('/add-retailer', (req, res, next) => {
    let retailer = req.body;
    Retailer.addRetailer(retailer, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err })
        } else {
            res.json({ success: true, data: "Retailer Added!" })
        }
    })
});

module.exports = router;

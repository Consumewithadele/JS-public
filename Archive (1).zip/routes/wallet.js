// Wallet routes
const express = require('express');
const router = express.Router();
const passport = require('passport');
const Wallet = require('../models/wallet');
const jwt = require('jsonwebtoken');
const config = require('../config/database');


/**
 * @api {get} /wallet/:id Get Wallet with specific id
 * @apiName GetWallet
 * @apiGroup Wallet
 * 
 * @apiParam {Number} id Wallet ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": wallet
 *     }
 *
 * @apiSuccess {Wallet} wallet
 */
router.get('/wallet/:id', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let id = req.params.id;
    Wallet.getWallet(id, (err, wallet)=> {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: wallet });
        }
    })
});

/**
 * @api {post} /add-wallet/ Add a Wallet
 * @apiName AddWallet
 * @apiGroup Wallet
 *
 * @apiParam {String} wallet_id Wallet ID
 * @apiParam {String} currency Wallet currency
 * @apiParam {Number} amount Wallet amount
 * @apiParam {Boolean} disable Wallet enabled or not
 *
 * @apiSuccess WalletAdded
 * 
 *  @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "message": "Wallet added!"
 *     }
 * 
 * @apiError ErrorMessage
 * 
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Error message"
 *     }
 */
router.post('/add-wallet', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let wallet = req.body;
    Wallet.addWallet(wallet, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: "Wallet added!" });
        }
    })
});

/**
 * @api {get} /list-wallets/ Get all wallets
 * @apiName GetWallet
 * @apiGroup Wallet
 * 
 * @apiParam {Number} page Page of wallets
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": wallets
 *     }
 *
 * @apiSuccess {Wallet} List of wallets
 */
router.get('/list-wallets', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let page = req.params.page;
    Wallet.getWallets(page, (err, wallets) => {
        if (err) {
            res.json({success: false, data: err})
        } else {
            res.json({success: true, data: wallets})
        }
    })
});

/**
 * @api {put} /wallet/ Update a Wallet
 * @apiName UpdateWallet
 * @apiGroup Wallet
 *
 * @apiParam {String} wallet_id Wallet ID
 * @apiParam {String} currency Wallet currency
 * @apiParam {Number} amount Wallet amount
 * @apiParam {Boolean} disable Wallet enabled or not
 *
 * @apiSuccess WalletUpdated
 * 
 *  @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "message": "Item updated!"
 *     }
 * 
 * @apiError ErrorMessage
 * 
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Error message"
 *     }
 */
router.put('/wallet', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let wallet =  req.body;
    Wallet.editWallet(wallet, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err })
        } else {
            res.json({ success: true, data: "Item updated!" })
        }
    })
});

/**
 * @api {delete} /wallet/:id Delete wallet with ID
 * @apiName DeleteWallet
 * @apiGroup Wallet
 * 
 * @apiParam {Number} id Wallet ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": "Item deleted!"
 *     }
 *
 */
router.delete('/wallet/:id', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let id = req.params.id;
    Wallet.deleteWallet(id, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err })
        } else {
            res.json({ success: true, data: "Item deleted!" })
        }
    })
})
module.exports = router;

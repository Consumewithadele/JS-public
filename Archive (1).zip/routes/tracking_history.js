// Tracking history routes.
const express = require('express');
const router = express.Router();
const passport = require('passport');
const TrackingHistory = require('../models/tracking_history');
const jwt = require('jsonwebtoken');
const config = require('../config/database');

/**
 * @api {get} /history/:id Get History by id
 * @apiName GetTrackingHistory
 * @apiGroup TrackingHistory
 * 
 * @apiParam {Number} id Tracking History ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": hisotyr
 *     }
 *
 * @apiSuccess {TrackingHistory} Tracking History
 */
router.get('/history/:id', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let id = req.params.id;
    TrackingHistory.getTrackingHistoryById(id, (err, history)=> {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: history });
        }
    })
});

/**
 * @api {post} /add-history/ Add Tracking History
 * @apiName AddTrackingHistory
 * @apiGroup TrackingHistory
 *
 * @apiParam {String} by_whom Sender
 * @apiParam {String} to_whom Receiver
 * @apiParam {String} location Location
 * @apiParam {String} distance_travel Distance travelled
 * @apiParam {Date} date date
 * @apiParam {Date} time time
 *
 * @apiSuccess TrackingHistoryAdded
 * 
 *  @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "message": "Recorded"
 *     }
 * 
 * @apiError ErrorMessage
 * 
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Error message"
 *     }
 */
router.post('/add-history', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let history = req.body;
    TrackingHistory.addtrackingHistory(history, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: "Recorded!" });
        }
    })
});

/**
 * @api {get} /list-history/ Get Tracking History
 * @apiName GetTrackingHistory
 * @apiGroup TrackingHistory
 * 
 * @apiParam {Number} page Page number for tracking history
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": history
 *     }
 *
 * @apiSuccess {TrackingHistory} All tracking History on said page
 */
router.get('/list-history', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let page = req.params.page;
    TrackingHistory.getTrackingHistories(page, (err, history) => {
        if (err) {
            res.json({success: false, data: err})
        } else {
            res.json({success: true, data: history})
        }
    })
});

/**
 * @api {put} /add-history/ Add Tracking History
 * @apiName AddTrackingHistory
 * @apiGroup TrackingHistory
 *
 * @apiParam {String} by_whom Sender
 * @apiParam {String} to_whom Receiver
 * @apiParam {String} location Location
 * @apiParam {String} distance_travel Distance travelled
 * @apiParam {Date} date date
 * @apiParam {Date} time time
 *
 * @apiSuccess TrackingHistoryAdded
 * 
 *  @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "message": "Item updated!"
 *     }
 * 
 * @apiError ErrorMessage
 * 
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Error message"
 *     }
 */
router.put('/history', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let history =  req.body;
    TrackingHistory.editTrackingHistory(history, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err })
        } else {
            res.json({ success: true, data: "Item updated!" })
        }
    })
});

/**
 * @api {delete} /history/:id Delete tracking history with ID
 * @apiName DeleteTrackingHistory
 * @apiGroup TrackingHistory
 * 
 * @apiParam {Number} id tracking history ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": "Item Removed!"
 *     }
 *
 */
router.delete('/history/:id', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let id = req.params.id;
    TrackingHistory.deleteTrackingHistory(id, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err })
        } else {
            res.json({ success: true, data: "Item deleted!" })
        }
    })
})
module.exports = router;

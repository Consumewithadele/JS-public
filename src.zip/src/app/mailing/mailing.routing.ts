import { Routes } from '@angular/router';

import { UserDashboardComponent } from './dashboard/dashboard.component';
import { ListBuilderComponent } from './list-builder/list-builder.component';
import { MailTimingComponent } from './mail-timing/mail-timing.component';
import { SelectDesignComponent } from './select-design/select-design.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { OrderSummaryComponent } from './order-summary/order-summary.component';
import { OrderConfirmedComponent } from './order-confirmed/order-confirmed.component';
import { OrderHistoryComponent } from './order-history/order-history.component';
import { PaymentComponent } from './payment/payment.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';


export const MailingRoutes: Routes = [
    {
      path: '',
      children: [ {
        path: 'buildlist',
        component: ListBuilderComponent
      }]
    },
    {
      path: '',
      children: [ {
        path: 'profile',
        component: UserProfileComponent
      }]
    },
    {
      path: '',
      children: [ {
        path: 'edit-profile',
        component: EditProfileComponent
      }]
    },
    {
      path: '',
      children: [ {
        path: 'payment',
        component: PaymentComponent
      }]
    },
    {
      path: '',
      children: [ {
        path: 'userprofile',
        component: UserDashboardComponent
       }]
    },

    {
      path: '',
      children: [ {
        path: 'mailtiming',
        component: MailTimingComponent
       }]
    },
    {
      path: '',
      children: [ {
        path: 'selectdesign',
        component: SelectDesignComponent
      }]
    },
    {
      path: '',
      children: [ {
        path: 'createaccount',
        component: CreateAccountComponent
      }]
    },
    {
      path: '',
      children: [ {
        path: 'checkout',
        component: OrderSummaryComponent
      }]
    },{
       path: '',
      children: [ {
        path: 'orderconfirmed',
        component: OrderConfirmedComponent
       }]
    },{
      path: '',
      children: [ {
        path: 'orderhistory',
        component: OrderHistoryComponent
      }]
    }
    ];
// Address model
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const config = require("../config/database");

const addressSchema = mongoose.Schema({
    wallet_id: {
        type: String
    },
    street: {
        type: String
    },
    city: {
        type: String
    },
    state: {
        type: String
    },
    zip: {
        type: String
    },
    country: {
        type: String
    },
    default: {
        type: String
    }
});

const Address = mongoose.model('Address', addressSchema);

// Get a single addres  by id
module.exports.getAddress = (id, callback) => {
    const query = { _id: id };
    Address.findOne(query, callback);
}

// Get All addresses 
module.exports.getAdress = (callback) => {
    Address.find(callback);
}

// Add address
module.exports.addAdress = (newAddress, callback) => {
    const address = new Address(newAddress);
    Address.save(callback)
}

//Edit address
module.exports.editAddress = (address, callback) => {
    const query = { _id: address._id };
    Address.update(query, address, callback);

}

// Delete address
module.exports.deleteAddress = (id, callback) => {
    const query = { _id: id };
    Address.remove(query, callback);
}
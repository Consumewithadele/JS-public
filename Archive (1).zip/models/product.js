// product model
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const config = require("../config/database");
const Schema = mongoose.Schema;

const productSchema = mongoose.Schema({
    wallet_id: {
        type: mongoose.Schema.Types.ObjectId, "ref": 'wallets'
    },
    vendor_id: {
        type: mongoose.Schema.Types.ObjectId, "ref": 'vendor'
    },
    product_name: {
        type: String,
        required: true
    },
    price: {
        type: Number
    },
    total_tax: {
        type: Number
    },
    date_time: {
        type: Date,
        default: Date.now
    }
})

const PRODUCT = mongoose.model('Product', productSchema);

// Add product mehtod
module.exports.addProduct = (newProduct, callback) => {
    const product = new PRODUCT(newProduct);
    product.save(callback)
}

// edit product
module.exports.editProduct = (productItem, callback) => {
    const query = { _id: productItem._id };
    PRODUCT.update(query, productItem, callback);
}

// delete product
module.exports.deleteProduct = (id, callback) => {
    PRODUCT.remove({ _id: id }, callback)
}

//  get products
module.exports.getProducts = (page, callback) => {
    PRODUCT.find(callback)
        .limit(20)
        .skip(20 * page)
        .sort({
            product_name: 'asc'
        });
}

// Get product by id
module.exports.getProductById = (id, callback) => {
    const query = { _id: id };
    PRODUCT.findOne(query, callback);
}
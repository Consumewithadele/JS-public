// Product routes 
const express = require('express');
const router = express.Router();
const passport = require('passport');
const Product = require('../models/product');
const jwt = require('jsonwebtoken');
const config = require('../config/database');

/**
 * @api {get} /list-products/ Get Products
 * @apiName GetProducts
 * @apiGroup Product
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": products
 *     }
 *
 * @apiSuccess {Product} List of products
 */
router.get('/list-products', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let page = req.params.page;
    Product.getProducts(page, (err, products) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: products });
        }
    });
});

/**
 * @api {post} /add-product/ Add a Product
 * @apiName AddProduct
 * @apiGroup Product
 *
 * @apiParam {Number} wallet_id Wallet ID
 * @apiParam {Number} vendor_id Vendor ID
 * @apiParam {String} product_name Product Name
 * @apiParam {Number} price Product price
 * @apiParam {Number} total_tax Total tax
 * @apiParam {Date} date_time Date and time
 *
 * @apiSuccess ProductAdded
 * 
 *  @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "message": "Product added!"
 *     }
 * 
 * @apiError ErrorMessage
 * 
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Error message"
 *     }
 */
router.post('/add-product', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let product = req.body;
    Product.addProduct(product, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err })
        } else {
            res.json({ success: true, data: "Product added!" });
        }
    })
});

/**
 * @api {put} /edit-product/ Edit a Product
 * @apiName EditProduct
 * @apiGroup Product
 *
 * @apiParam {Number} wallet_id Wallet ID
 * @apiParam {Number} vendor_id Vendor ID
 * @apiParam {String} product_name Product Name
 * @apiParam {Number} price Product price
 * @apiParam {Number} total_tax Total tax
 * @apiParam {Date} date_time Date and time
 *
 * @apiSuccess ProductEdited
 * 
 *  @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "message": "Product updated!"
 *     }
 * 
 * @apiError ErrorMessage
 * 
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Failed to update product!"
 *     }
 */
router.put('/edit-product', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let product = req.body;
    Product.editProduct(product, (err, callback) => {
        if (err) {
            res.json({ success: false, data: "Failed to update product!" })
        } else {
            res.json({ success: true, data: "Product updated!" })
        }
    })
});

/**
 * @api {delete} /remove-product/:id Delete product with ID
 * @apiName DeleteProduct
 * @apiGroup Product
 * 
 * @apiParam {Number} id Product ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": "Product Removed!"
 *     }
 *
 */
router.delete('/remove-product/:id', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let id = req.params.id;
    Product.deleteProduct(id, (err, callback) => {
        if (err) {
            res.json({ success: false, data: "Failed request!" })
        } else {
            res.json({ success: true, data: "Product removed!" });
        }
    })
});

/**
 * @api {get} /product/:id Get Product with specific id
 * @apiName GetProduct
 * @apiGroup Product
 * 
 * @apiParam {Number} id Product ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": product
 *     }
 *
 * @apiSuccess {Product} product
 */
router.get('/product/:id', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let id = req.params.id;
    Product.getProductById(id, (err, product) => {
        if (err) {
            res.json({ success: false, data: "Failed request!" })
        } else {
            res.json({ success: true, data: product });
        }
    })
})

module.exports = router;
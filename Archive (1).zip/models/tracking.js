// tracking  model
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const config = require("../config/database");

const trackingSchema = mongoose.Schema({
    by_whom: {
        type: String,
        required: true
    }, 
    to_whom: {
        type: String,
        required: true
    }, 
    auth: {
        type: String
    }
});

const TRACKING = mongoose.model('Tracking', trackingSchema);

//  add tracking
module.exports.addTracking = (newTracking, callback) => {
    const tracking = new TRACKING(newTracking);
    tracking.save(callback);
}   

// edit tracking
module.exports.editTracking = (trackingItem, callback) => {
    const query = {_id: trackingItem.id};
    TRACKING.update(query, employeeItem, callback);
}

// delete tracking
module.exports.deleteTracking = (id, callback) => {
    const query = {_id: id};
    TRACKING.remove(query, callback)
}

// Get trackings 
module.exports.getTrackings = (page, callback) => {
    TRACKING.find(callback)
}

// Get tracking by Id 
module.exports.getTrackingById = (id, callback) => {
    const query = {_id: id};
    TRACKING.findOne(query, callback);
}


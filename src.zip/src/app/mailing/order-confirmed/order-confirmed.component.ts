import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order-confirmed',
  templateUrl: './order-confirmed.component.html',
  styleUrls: ['./order-confirmed.component.css']
})
export class OrderConfirmedComponent implements OnInit {

  constructor(private router:Router) { }
   
  navigateTo(){
    this.router.navigateByUrl("/mail/orderhistory");
  }

  ngOnInit() {
  }

}

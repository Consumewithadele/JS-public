// This is users routes
const express = require('express');
const router = express.Router();
const passport = require('passport');
const User = require('../models/user');
const jwt = require('jsonwebtoken');
const config = require('../config/database');

/**
 * @api {post} /register/ Register a User
 * @apiName RegisterUsers
 * @apiGroup Users
 *
 * @apiParam {String} name Users name
 * @apiParam {String} email Users email
 * @apiParam {Number} mobile Users phone number
 * @apiParam {Number} country_code Users country code
 * @apiParam {String} role Users role
 * @apiParam {String} password Users password
 *
 * @apiSuccess UserRegistered
 * 
 *  @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "message": "User Registered"
 *     }
 * 
 * @apiError ErrorMessage
 * 
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Error message"
 *     }
 */
router.post('/register', (req, res, next) => {
	let newUser = {
		name: req.body.name,
		email: req.body.email,
		mobile: req.body.mobile,
		country_code: req.body.country_code,
		role: (req.body.role).toLowerCase(),
		password: req.body.password
	};
	// check if user is a normal user or vendor
	if (newUser.role === 'vendor') {
		newUser.org_name = req.body.org_name;
		User.addVendor(newUser, (err, callback) => {
			if (err) {
				res.json({ message: err, success: false });
			} else {
				res.json({ message: 'User registered!', success: true });
			}
		})
	} else {
		User.addUser(newUser, (err, user) => {
			if (err) {
				res.json({ message: err, success: false });
			} else {
				res.json({ message: 'User registered!', success: true });
			}
		})
	}
});

/**
 * @api {post} /authenticate/ Authenticate a User
 * @apiName AuthenticateUser
 * @apiGroup Users
 *
 * @apiParam {String} name Users name
 * @apiParam {String} password Users password
 *
 * @apiSuccess UserRegistered
 * 
 *  @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "token": "12345678",
 * 		 "user": user
 *     }
 * 
 * @apiError ErrorMessage
 * 
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Password or username not correct!"
 *     }
 */
router.post('/authenticate', (req, res, next) => {
	let email = req.body.email;
	let password = req.body.password;
	User.getUserByUserEmail(email, (err, user) => {
		if (user) {
			User.comparePassword(password, user.password, (error, isMatch) => {
				if (isMatch) {
					const payload = {id: user._id, email: user.email, password: user.password };
					const token = jwt.sign(payload, config.secret, {
						expiresIn: 259200 // 3 days
					});
					// send respond	
					user.password = null;
					res.json({
						success: true,
						token: 'JWT ' + token,
						user: user
					})
				} else {
					res.json({ success: false, message: "Password or username not correct!" });
				}
			})

		} else {
			return res.json({ success: false, message: "User not found!" })
		}
	})
});


/**
 * @api {get} /profile/ Get a User profile
 * @apiName GetUsers
 * @apiGroup Users
 *
 *
 * @apiSuccess {Users} Profile of User
 * 
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 * 		 "user": user
 *     }
 */
router.get('/profile', passport.authenticate('jwt', { session: false }), (req, res, next) => {
	req.user.password = null;
	res.json({ user: req.user });
});

/**
 * @api {get} /list-users/ Request User information
 * @apiName GetUsers
 * @apiGroup Users
 *
 *
 * @apiSuccess {Users} List of users
 */
router.get('/list-users', passport.authenticate('jwt', { session: false }), (req, res, next) => {
	let page = req.params.page;
	User.getUsers(page, (err, users) => {
		if (err) {
			res.json({ success: false, data: err })
		} else {
			res.json({ success: true, data: users })
		}
	})
})

module.exports = router;
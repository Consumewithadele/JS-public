// user model
const mongoose = require("mongoose");
const extend = require('mongoose-schema-extend');
const bcrypt = require("bcryptjs");
const config = require("../config/database");


const options = { discriminatorKey: 'role' };

// User Schema
const UserSchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    country_code: {
        type: Number,
        required: true
    },
    mobile: {
        type: Number,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    wallet_id: {
        type: String
    },
    ip: {
        type: String
    },
    device_id: {
        type: String
    },
    os: {
        type: String,
    },
    date_time: {
        type: Date,
        default: Date.now
    },
    disable: {
        type: Boolean,
        default: false
    },
    verify_m: {
        type: Boolean,
        default: false
    },
    verify_e: {
        type: Boolean,
        default: false
    },
    currency: {
        type: String
    },
    aadhar: {
        type: String
    },
    pan_card: {
        type: String
    },
    birthdate: {
        type: String
    },
    fb_id: {
        type: String
    },
    instagram_id: {
        type: String
    },
    twitter_id: {
        type: String
    },
    ekyc: {
        type: String
    },
    profile_pic: {
        data: Buffer,
        contentType: String
    },
    role: {
        type: [{
            type: String,
            enum: ['user', 'admin', 'vendor']
        }],
        default: 'user'
    },
}, options);

// Vendo Schema (extends user Schema)
const VendorSchema = mongoose.Schema({
    org_name: {
        type: String,
        required: true
    },
    org_birthdate: {
        type: Date
    },
    org_pic: {
        data: Buffer,
        contentType: String
    },
    license: {
        type: String
    },
    other_license: {
        type: String
    },
    category: {
        type: String
    },
    free_delivery: {
        type: Boolean,
        default: false
    },
    delivery_charge: {
        type: String,
    },
    shipping: {
        type: String
    },
    shipping_charges: {
        type: String
    },
    min_order: {
        type: Number
    }
}, options);

// Admin SChmea
const AdminSchema = mongoose.Schema({
    super_user: {
        type: Boolean,
        default: true
    }
});



const User = module.exports = mongoose.model('user', UserSchema);
const Vendor = User.discriminator('vendor', VendorSchema);
const Admin = User.discriminator('admin', AdminSchema);

/*********** user db opreations  *********************/

// Get user by id
module.exports.getUserById = (id, callback) => {
    User.findById(id, callback)
};

// Get all users id 
module.exports.getUsers = (page, callback) => {
    User.find(callback)
        .limit(20)
        .skip(20 * page)
        .select('-password')
}
// Get a user by username.
module.exports.getUserByUserEmail = (email, callback) => {
    const query = { email: email };
    User.findOne(query, callback)
};

// Add new user to db
module.exports.addUser = (newUser, callback) => {
    const user = new User(newUser);
    // Hash user password
    bcrypt.genSalt(10, (err, salt) => {
        bcrypt.hash(newUser.password, salt, (err, hash) => {
            if (err) {
                return err
            } else {
                user.password = hash;
                user.save(callback);
            }
        })
    })
}

// Add new retialer
module.exports.addVendor = (newVendor, callback) => {
    const vendor = new Vendor(newVendor);
    // Hash user password
    bcrypt.genSalt(10, (err, salt) => {
        bcrypt.hash(newVendor.password, salt, (err, hash) => {
            if (err) {
                return err
            } else {
                vendor.password = hash;
                vendor.save(callback);
            }
        })
    })
}

// Edit user details
module.exports.editUser = (user, callback) => {
    const query = { _id: user._id };
    User.update(query, user, callback);
}

// Delete user
module.exports.deleteUser = (id, callback) => {
    const query = { _id: id };
    User.remove(query, callback);
}

// compare  user password
module.exports.comparePassword = (candidatePassword, hash, callback) => {
    bcrypt.compare(candidatePassword, hash, (err, isMatch) => {
        if (err) return err;
        callback(null, isMatch);
    })
}
/****************** End of user db methods  *******************/
export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyDKTteH_wm5s-7Qg-C6lcEaI_cuogjVaww",
    authDomain: "mailer-10f73.firebaseapp.com",
    databaseURL: "https://mailer-10f73.firebaseio.com",
    projectId: "mailer-10f73",
    storageBucket: "mailer-10f73.appspot.com",
    messagingSenderId: "540895898949"
  }
};

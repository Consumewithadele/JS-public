import { SortZipPipe } from './../../pipes/sort-zip.pipe';
import { BuildlistService } from './../../services/buildlist.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-builder',
  templateUrl: './list-builder.component.html',
  styleUrls: ['./list-builder.component.css'],
})
export class ListBuilderComponent implements OnInit {
  public loadingStates = false;
  public loadingZips = false;
  public loadingSubdivisions = false;
  public updatingCount = false;
  public states = <any>[];
  public zipCodes = <any>[];
  public subdivisions = <any>[];
  public state: any;
  public geoId:String;
  public houseCount: number = 0;
  constructor(private router:Router, private buildListService: BuildlistService) { }

  navigateTo(){
    this.router.navigateByUrl("/mail/mailtiming");
  }

  ngOnInit() {
    this.loadStates();
  }

  // load states from API
  loadStates(){
    this.loadingStates = true;
    this.buildListService.getStates().subscribe(snapshots => {
      snapshots.forEach(snapshot => {
        //console.log(snapshot);
        this.states.push(snapshot);
      });
      this.loadingStates = false;
    })
  }

  // Get zip codes from for a given state.
  loadZipcodes(stateName:String){
    this.houseCount = 0;
    this.subdivisions = [];
    this.loadingZips = true;
      let zipcodesForState:any = [];
      this.buildListService.getStateZips(stateName).subscribe(snapshots => {
        snapshots.forEach(snapshot => {
          //console.log(snapshot);
          this.zipCodes.push(snapshot.ZIP_CODE);
        });
        this.loadingZips = false;
      })
  }

  // Get subdivisions of a specified zpcode
  loadSubdivisions(zipcode: String){
    this.loadingSubdivisions = true;
    let zipcodesForState:any = [];
    this.buildListService.getSubdivisions(zipcode).subscribe(snapshots => {
      snapshots.forEach(snapshot => {
       // console.log(snapshot);
        this.subdivisions.push(snapshot);
      });
      this.loadingSubdivisions = false;
    })
  }

  /*
  * update property count method this method is called when a subdivision is checked or unchecked
  * It adds the property count from API with current count when checked (implies event == true)
  * subtracts from the total count if unchecked (event == false)
  * @params (geo_id)
  */
  addPropertyCount(event:any, geo_id: String){
    this.updatingCount = true;
    let diffType:boolean = false;
    this.buildListService.getPropertyCount(geo_id).subscribe((res:any) => {
      if (res.status == 200) {
        console.log(res);
        let data = JSON.parse(res._body);
        let count = data.status.total;
        if (event == true){
          this.houseCount += count;
          this.updatingCount = false;
        } else {
          this.houseCount -= count;
          this.updatingCount = false;
        }
        console.log(count);
      } else {
        diffType = true;
        console.log('Something went wrong')
        this.updatingCount = false;
      }
    }, (err) => {
      console.log('property is not SFR checking condominium ...');
      this.buildListService.getPropertyCountForCondominuim(geo_id).subscribe((res:any) => {
        if (res.status == 200) {
          console.log(res);
          let data = JSON.parse(res._body);
          let count = data.status.total;
          if (event == true){
            this.houseCount += count;
            this.updatingCount = false;
          } else {
            this.houseCount -= count;
            this.updatingCount = false;
          }
          console.log(count);
        } else {
          console.log('Something went wrong')
          this.updatingCount = false;
        }
      })
      this.updatingCount = false;
    })

  }

  

}

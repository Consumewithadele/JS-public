import { equal } from 'assert';
import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { AngularFireDatabase, FirebaseListObservable } from 'angularfire2/database';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/retry';
import 'rxjs/add/operator/timeout';
import 'rxjs/add/operator/delay';
import 'rxjs/add/operator/map';



@Injectable()
export class BuildlistService {
  public baseUrl = "https://search.onboard-apis.com";
  public subdivisions: FirebaseListObservable<any[]>;
  public states: FirebaseListObservable<any[]>;

  constructor(private http: Http, private af: AngularFireDatabase ) {
      this.subdivisions = af.list('/subs');
      this.states = af.list('/states');

   }

  // Get states
  getStates(){
    return this.states;
  }

  // Get the zipcodes belonging to a particular state @param(stateName)
  getStateZips(stateName: String) {
    let zipsForstate = this.af.list('subs', {
      query:{
        orderByChild: 'SEARCH_STATE_NAME',
        equalTo: stateName
      }
    });
    return zipsForstate; 
  }

  // Get the subdivisions of a specified zipcode.
  getSubdivisions(zipcode: String){
    let subdivisions = this.af.list('subs', {
      query:{
        orderByChild: 'ZIP_CODE',
        equalTo: zipcode
      }
    });
    return subdivisions; 
  }

  // Get property count from API for SFR
  getPropertyCount(geo_id: String){
    let data = {
      geo_id: geo_id
    } 
    let headers = new Headers({'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
    return this.http.post('https://us-central1-mailer-10f73.cloudfunctions.net/api/getPropertyCountSFR', data, {headers:headers})
      //.timeout(15000) // Timeout of 15 secs, terminate request if no response after 15 secs.
      .map((res: Response) => {
          return res;
      })
           

  }
  

  // Get properety count for conduminuim
  getPropertyCountForCondominuim(geo_id: String){
    let headers = new Headers({'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
    let data = {
      geo_id: geo_id
    }
    return this.http.post('https://us-central1-mailer-10f73.cloudfunctions.net/api/getPropertyCountCONDOMINIUM', data, {headers:headers})
     // .timeout(15000) // Timeout of 15 secs, terminate request if no response after 15 secs.
      .map((res: Response) => {
          return res;
      })
  }


}

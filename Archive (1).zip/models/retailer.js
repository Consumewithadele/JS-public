// // Retailer model
// const mongoose = require("mongoose");
// const bcrypt = require("bcryptjs");
// const config = require("../config/database");

// const retailerSchema = mongoose.Schema({
//     org_name: {
//         type: String,
//         required: true
//     }, 
//     country_code: {
//         type: Number,
//         required: true
//     },
//      mobile: {
//          type: Number,
//          required: true
//      }, 
//      email: {
//          type: String
//      }, 
//      password: {
//          type: String,
//          required: String
//      }, 
//      wallet_id:{
//          type: String
//      }, 
//      ip: {
//          type: String
//      }, 
//      device_id: {
//          type: String
//      }, 
//      os: {
//          type: String
//      }, 
//      date_time: {
//          type: Date,
//          default: Date.now
//      }, 
//      disable: {
//          type: Boolean,
//          default: false
//      }, 
//      verify_m: {
//          type: Boolean,
//          default: false
//      }, 
//      verify_e: {
//          type: Boolean,
//          default: false,
//      }, 
//      currency: {
//          type: String,
//          default: "USD"
//      }, 
//      aadhar:{
//          type: String
//      }, 
//      pan_card: {
//          type: String
//      }, 
//      org_birthdate: {
//          type: Date
//      }, 
//      fb_id:{
//          type: String
//      }, 
//      instagram_id: {
//          type: String
//      }, 
//      twitter_id: {
//          type: String
//      }, 
//      ekyc:{
//          type: String
//      }, org_pic: {
//           data: Buffer, 
//           contentType: String 
//      }, 
//      license: {
//          type: String
//      }, 
//      other_license: {
//          type: String
//      }, 
//      category: {
//          type: String
//      }, 
//      free_delivery:{
//          type: Boolean,
//          default: false
//      }, 
//      delivery_charge: {
//          type: String,
//      }, 
//      shipping: {
//          type: String
//      }, 
//      shipping_charges: {
//          type: String
//      }, 
//      min_order: {
//          type: Number
//      }
// });

// const RETAILER = mongoose.model('Retailer', retailerSchema);

// // Add retailer 
// module.exports.addRetailer = (newRetailer, callback) => {
//     const retailer = new RETAILER(newProduct);
//     retailer.save(callback);
// };

// // Get retailers 
// module.exports.getRetailers = (page, callback) => {
//     RETAILER.find(callback)
//     .limit(20)
//     .skip(20 * page)
//     .sort({
//         org_name: 'asc'
//     }); 
// };

// // Get retailer by Id
// module.exports.getRetailerById = (id, callback) => {
//     const query = {_id: id};
//     RETAILER.findOne(query, callback);
// };

// // edit retailer
// module.exports.editRetailer = (retailer, callback) => {
//     const query = {_id: retailer._id};
//     RETAILER.update(query, retailer, callback);
// };

// // delete retailer
// module.exports.deleteRetailer = (id, callback) => {    
//     RETAILER.remove({_id: id}, callback)
// };


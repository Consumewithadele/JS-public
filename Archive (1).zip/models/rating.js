// Rating model
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const config = require("../config/database");

const ratingSchema  = mongoose.Schema({
    invoice: {
        type: String
    }, 
    buyer: {
        type: String
    }, 
    seller:{
        type: String
    }, 
    avg_rate: {
        type: Number
    }, 
    total_rating: {
        type: Number
    }
});

const RATING = mongoose.model('Rating', ratingSchema);

// TODO: rating methods
// Order routes
const express = require('express');
const router = express.Router();
const passport = require('passport');
const Orders = require('../models/order');
const jwt = require('jsonwebtoken');
const config = require('../config/database');

/**
 * @api {get} /seller-orders/:sellerId Get Orders for a specific seller
 * @apiName GetOrders
 * @apiGroup Order
 * 
 * @apiParam {Number} sellerId Seller ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": orders
 *     }
 *
 * @apiSuccess {Order} List of orders with a specific sellerId
 */
router.get('/seller-orders/:sellerId', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let sellerId = req.params.sellerId;
    let page = req.params.page;
    Orders.getOrdersOfSeller(sellerId, page, (err, orders) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: orders });
        }
    })
});

/**
 * @api {get} /buyer-orders/:buyerId Get Orders for a specific buyer
 * @apiName GetOrders
 * @apiGroup Order
 * 
 * @apiParam {Number} buyerId Buyer ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": orders
 *     }
 *
 * @apiSuccess {Order} List of orders with a specific buyerId
 */
router.get('/buyer-orders/:buyerId',  passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let buyerId = req.params.buyerId;
    let page = req.params.page;
    Orders.getOrdersByBuyerId(buyerId, page, (err, orders) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: orders });
        }
    })
});

/**
 * @api {get} /list-orders/ Get Orders
 * @apiName GetOrders
 * @apiGroup Order
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": orders
 *     }
 *
 * @apiSuccess {Order} List of orders
 */
router.get('/list-orders',  passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let page = req.params.page;
    Orders.getOrders(page, (err, orders) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: orders });
        }
    })
});

/**
 * @api {get} /:id Get Order with specific id
 * @apiName GetOrder
 * @apiGroup Order
 * 
 * @apiParam {Number} id Order ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": order
 *     }
 *
 * @apiSuccess {Order} order
 */
router.get('/:id',  passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let id = req.params.id;
    Orders.getOrderById(id, (err, order) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: order });
        }
    })
});

/**
 * @api {post} /add-order/ Add an Order
 * @apiName AddOrder
 * @apiGroup Order
 *
 * @apiParam {Date} date Date of order
 * @apiParam {Object} invoice Order invoice
 * @apiParam {String} buyer Buyer Name
 * @apiParam {String} seller seller name
 * @apiParam {String} current_status Order status
 * @apiParam {Object} tracking Order tracking
 * @apiParam {String} ip Order ip
 * @apiParam {String} link Order link
 *
 * @apiSuccess OrderAdded
 * 
 *  @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "message": "Order Added successfully"
 *     }
 * 
 * @apiError ErrorMessage
 * 
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Error message"
 *     }
 */
router.post('/add-order',  passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let order = req.body;
    Orders.addOrder(order, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: "Order added successfully!" });
        }
    })
});

/**
 * @api {put} /edit-order/ Edit an Order
 * @apiName EditOrder
 * @apiGroup Order
 *
 * @apiParam {Date} date Date of order
 * @apiParam {Object} invoice Order invoice
 * @apiParam {String} buyer Buyer Name
 * @apiParam {String} seller seller name
 * @apiParam {String} current_status Order status
 * @apiParam {Object} tracking Order tracking
 * @apiParam {String} ip Order ip
 * @apiParam {String} link Order link
 *
 * @apiSuccess OrderAdded
 * 
 *  @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "message": "Order updated!"
 *     }
 * 
 * @apiError ErrorMessage
 * 
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Failed to update order!"
 *     }
 */
router.put('/edit-order',  passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let order = req.body;
    Orders.editOrder(order, (err, callback) => {
        if (err) {
            res.json({success: false, data: "Failed to update order!"})
        } else {
            res.json({success:true, data: "Order updated!"})
        }
    })
});

/**
 * @api {delete} /remove-order Delete Order
 * @apiName DeleteOrder
 * @apiGroup Order
 * 
 * @apiParam {Number} id Employee ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": "Order Removed!"
 *     }
 *
 */
router.delete('/remove-order',  passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let id = req.params.id;
    Product.deleteOrder(id, (err, callback) => {
        if (err) {
            res.json({success:false, data: "Failed request!"})
        } else{
            res.json({success:true, data: "Order removed!"});
        }
    })
});


module.exports = router;
// Wallet transaction model
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const config = require("../config/database");

const WalletTransactionSchema = mongoose.Schema({
    date: {
        type: Date,
        default: Date.now
    },
    sender: {
        type: mongoose.Schema.Types.ObjectId, "ref": 'user'
    },
    receiver: {
        type: mongoose.Schema.Types.ObjectId, "ref": 'user'
    },
    currency: {
        type: String
    },
    amount: {
        type: Number
    },
    note: {
        type: String
    },
    excahnge_rate: {
        type: Number
    },
    ip: {
        type: String
    }
})

const WalletTransaction = mongoose.model('WalletTransaction', WalletTransactionSchema);

// Get a single transaction by id
module.exports.getTransactionById = (id, callback) => {
    const query = { _id: id };
    WalletTransaction.findOne(query, callback);
}

// Get All transactions 
module.exports.getTransactions = (page, callback) => {
    WalletTransaction.find(callback)
        .limit(20)
        .skip(20 * page);
}

// Add Transaction
module.exports.createTransaction = (newTransaction, callback) => {
    const transaction = new WalletTransaction(newTransaction);
    transaction.save(callback)
}

//Edit transaction
module.exports.editTransaction = (transactionItem, callback) => {
    const query = { _id: transactionItem._id };
    WalletTransaction.update(query, transactionItem, callback);

}

// Delete transaction
module.exports.deleteTransaction = (id, callback) => {
    const query = { _id: id };
    WalletTransaction.remove(query, callback);
}
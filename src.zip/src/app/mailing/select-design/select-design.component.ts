import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-select-design',
  templateUrl: './select-design.component.html',
  styleUrls: ['./select-design.component.css']
})
export class SelectDesignComponent implements OnInit {
  
  selectColor = 'warning';
    
    cities = [
      {value: 'paris-0', viewValue: 'Paris'},
      {value: 'miami-1', viewValue: 'Miami'},
      {value: 'bucharest-2', viewValue: 'Bucharest'},
      {value: 'new-york-3', viewValue: 'New York'},
      {value: 'london-4', viewValue: 'London'},
      {value: 'barcelona-5', viewValue: 'Barcelona'},
      {value: 'moscow-6', viewValue: 'Moscow'},
    ];
    
  constructor(private router:Router) { }

  navigateTo(){
    this.router.navigate(['/mail/createaccount']);
  }

  ngOnInit() {
  }

}

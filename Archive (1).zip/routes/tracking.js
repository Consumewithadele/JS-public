// Tracking routes
const express = require('express');
const router = express.Router();
const passport = require('passport');
const Tracking = require('../models/tracking');
const jwt = require('jsonwebtoken');
const config = require('../config/database');

/**
 * @api {get} /tracking/:id Get Tracking with specific id
 * @apiName GetTracking
 * @apiGroup Tracking
 * 
 * @apiParam {Number} id Tracking ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": tracking
 *     }
 *
 * @apiSuccess {Tracking} tracking
 */
router.get('/tracking/:id', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let id = req.params.id;
    Tracking.getTrackingById(id, (err, tracking)=> {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: tracking });
        }
    })
});

/**
 * @api {post} /add-tracking/ Add Tracking
 * @apiName AddTracking
 * @apiGroup Tracking
 *
 * @apiParam {String} by_whom sender
 * @apiParam {String} to_whom receiver
 * @apiParam {String} auth Authentication
 *
 * @apiSuccess TrackingAdded
 * 
 *  @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "message": "Tracking added!"
 *     }
 * 
 * @apiError ErrorMessage
 * 
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Request failed!"
 *     }
 */
router.post('/add-tracking', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let tracking = req.body;
    Tracking.addTracking(tracking, (err, callback) => {
        if (err) {
            res.json({ success: false, data: 'Request failed!' });
        } else {
            res.json({ success: true, data: "Tracking added!" });
        }
    })
});

/**
 * @api {get} /list-trackings/ Get all trackings
 * @apiName GetTracking
 * @apiGroup Tracking
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": trackings
 *     }
 *
 * @apiSuccess {Tracking} List of trackings
 */
router.get('/list-trackings', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let page = req.params.page;
    Tracking.getTrackings(page, (err, trackings) => {
        if (err) {
            res.json({success: false, data: err})
        } else {
            res.json({success: true, data: trackings})
        }
    })
});

/**
 * @api {put} /tracking/:id Update Tracking with ID
 * @apiName AddTracking
 * @apiGroup Tracking
 *
 * @apiParam {Number} id tracking ID
 *
 * @apiSuccess TrackingUpdated
 * 
 *  @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "message": "Item updated!"
 *     }
 * 
 * @apiError ErrorMessage
 * 
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Request failed!"
 *     }
 */
router.put('/tracking/:id', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let id =  req.params.id;
    Tracking.editTracking(id, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err })
        } else {
            res.json({ success: true, data: "Item updated!" })
        }
    })
});

/**
 * @api {delete} /tracking/:id Delete tracking with ID
 * @apiName DeleteTracking
 * @apiGroup Tracking
 * 
 * @apiParam {Number} id Tracking ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": "Item Deleted!"
 *     }
 *
 */
router.delete('/tracking/:id', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let id = req.params.id;
    Tracking.deleteTracking(id, (err, callback) => {
        if (err) {
            res.json({ success: false, data: err })
        } else {
            res.json({ success: true, data: "Item deleted!" })
        }
    })
})
module.exports = router;

// Employee routes
const express = require('express');
const router = express.Router();
const passport = require('passport');
const Employees = require('../models/employee');
const jwt = require('jsonwebtoken');
const config = require('../config/database');

/**
 * @api {post} /add-employee/ Add an Employee
 * @apiName AddEmployee
 * @apiGroup Employee
 *
 * @apiParam {String} retailer Retailer
 * @apiParam {Number} id Employee ID
 * @apiParam {String} emp_name Employee Name
 * @apiParam {String} country_code Employee country code
 * @apiParam {Boolean} status Employee status
 * @apiParam {String} role Employee role
 *
 * @apiSuccess EmployeeAdded
 * 
 *  @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "message": "Employee Added!"
 *     }
 * 
 * @apiError ErrorMessage
 * 
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Error message"
 *     }
 */
router.post('/add-employee', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let employee = req.body;
    Employees.addEmployee(employee, (err, callback)=> {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: "Employee Added!" });
        }
    })
});

/**
 * @api {get} /list-employees/ Get Employees
 * @apiName GetEmployees
 * @apiGroup Employee
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": employees
 *     }
 *
 * @apiSuccess {Employee} List of employees
 */
router.get('/list-employees', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let page = req.params.page;
    Employees.getEmployees(page, (err, employees) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: employees });
        }
    })
});

/**
 * @api {get} /retailer/employees/:retailerId Get Employees with a specific retailerId
 * @apiName GetEmployees
 * @apiGroup Employee
 * 
 * @apiParam {Number} retailerId Retailer ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": employees
 *     }
 *
 * @apiSuccess {Employee} List of employees with a specific retailerId
 */
router.get('/retailer/employees/:retailerId', passport.authenticate('jwt', { session: false }),  (req, res, next) => {
    let id = req.params.retailerId;
    Employees.getEmployeesOfRetailer(page, (err, employees) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: employees });
        }
    })
});

/**
 * @api {get} /:id Get Employee with id
 * @apiName GetEmployees
 * @apiGroup Employee
 * 
 * @apiParam {Number} id Employee ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": employee
 *     }
 *
 * @apiSuccess {Employee} get and employee
 */
router.get('/:id', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let id = req.params.id;
    Employees.getEmployeeById(id, (err, employee) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: employee });
        }
    })
});

/**
 * @api {put} /update/:id Update an Employee
 * @apiName UpdateEmployee
 * @apiGroup Employee
 *
 * @apiParam {String} retailer Retailer
 *
 * @apiSuccess EmployeeUpdated
 * 
 *  @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": Employee
 *     }
 * 
 * @apiError ErrorMessage
 * 
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Error message"
 *     }
 */
router.put('/update/:id', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let employee = req.body;
    Employees.editEmployee(employee, (err, employee) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: employee });
        }
    })
});

/**
 * @api {delete} /remove/:id Delete Employee with id
 * @apiName DeleteEmployee
 * @apiGroup Employee
 * 
 * @apiParam {Number} id Employee ID
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "data": "Employee Removed!"
 *     }
 *
 * @apiSuccess {Employee} get and employee
 */
router.delete('/remove/:id', passport.authenticate('jwt', { session: false }), (req, res, next) => {
    let id = req.body.id;
    Employees.deleteEmployee(id, (err, employee) => {
        if (err) {
            res.json({ success: false, data: err });
        } else {
            res.json({ success: true, data: "Employee Removed!" });
        }
    })
});

module.exports = router;
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SelectModule } from 'ng2-select';
import { MdDatepickerModule, MdInputModule, MdNativeDateModule, MdSelectModule } from '@angular/material';
import { DatepickerModule } from 'angular2-material-datepicker'
import { MdModule } from '../md/md.module';

import { MailingRoutes } from './mailing.routing';
import { UserDashboardComponent } from './dashboard/dashboard.component';
import { ListBuilderComponent } from './list-builder/list-builder.component';
import { MailTimingComponent } from './mail-timing/mail-timing.component';
import { SelectDesignComponent } from './select-design/select-design.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { OrderSummaryComponent } from './order-summary/order-summary.component';
import { OrderConfirmedComponent } from './order-confirmed/order-confirmed.component';
import { OrderHistoryComponent } from './order-history/order-history.component';
import { PaymentComponent } from './payment/payment.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(MailingRoutes),
    FormsModule,
    MdDatepickerModule,
    MdInputModule, 
    MdNativeDateModule, 
    MdSelectModule,
    MdModule,
    DatepickerModule
  ],
  declarations: [
              UserDashboardComponent,
              ListBuilderComponent,
              MailTimingComponent,
              SelectDesignComponent,
              CreateAccountComponent,
              OrderSummaryComponent,
              OrderConfirmedComponent,
              OrderHistoryComponent,
              PaymentComponent,
              UserProfileComponent,
              EditProfileComponent
          ]
})

export class MailingModule {}

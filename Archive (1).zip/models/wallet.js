// Wallet model
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const config = require("../config/database");

const WalletSchema = mongoose.Schema({
    wallet_id : {
        type: String,
        unique: true
    }, 
    currency: {
        type: String
    }, 
    amount:{
        type: Number
    },
    disable: {
        type: Boolean,
        default: false
    }
})

const Wallet = mongoose.model('Wallet', WalletSchema);
// Get a single wallet by id
module.exports.getWallet = (id, callback) => {
    const query = { _id: id };
    Wallet.findOne(query, callback);
}

// Get All wallets 
module.exports.getWallets = (page, callback) => {
    Wallet.find(callback)    
    .limit(20)
    .skip(20 * page);;
}

// Add wallet
module.exports.addWallet = (newWallet, callback) => {
    const wallet = new Wallet(newWallet);
    wallet.save(callback)
}

//Edit wallet
module.exports.editWallet = (walletItem, callback) => {
    const query = { _id: walletItem._id };
    Wallet.update(query, walletItem, callback);

}

// Delete wallet
module.exports.deleteWallet = (id, callback) => {
    const query = { _id: id };
    Wallet.remove(query, callback);
}
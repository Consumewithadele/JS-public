// Bank model
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const config = require("../config/database");

const bankSchema = mongoose.Schema({
    wallet_id: {
        type: String,
        required: true
    },
    name: {
        type: String
    },
    address: {
        type: String
    },
    account_name: {
        type: String
    },
    account_number: {
        type: String,
        unique: true
    },
    ifci_code: {
        type: String,
        unique: true
    }, 
    default: {
        type: String,
    }
});

const Bank  = mongoose.model('Bank', bankSchema);

// Get a single bank by id
module.exports.getbank = (id, callback) => {
    const query = { _id: id };
    Bank.findOne(query, callback);
}

// Get All banks 
module.exports.getWallets = (callback) => {
    Bank.find(callback);
}

// Add bank
module.exports.addBank = (newBank, callback) => {
    const bank = new Bank(newBank);
    bank.save(callback)
}

//Edit Bank
module.exports.editBank = (bankItem, callback) => {
    const query = { _id: bankItem._id };
    Bank.update(query, bankItem, callback);

}

// Delete bank
module.exports.deleteWallet = (id, callback) => {
    const query = { _id: id };
    Bank.remove(query, callback);
}